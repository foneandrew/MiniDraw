/* Code for COMP 102 Assignment 10
 * Name:
 * Usercode:
 * ID:
 */

import java.util.*;
import comp102.*;
import java.awt.Color;
import java.io.*;

/** Polgon represents a polygon made of a sequence of straight lines.
   Implements the Shape interface.
   Has a field to record the colour of the line and two fields to store
   lists of the x coordinates and the y coordinates of all the vertices
 */


public class Polygon implements Shape{
    // YOUR CODE HERE

}
